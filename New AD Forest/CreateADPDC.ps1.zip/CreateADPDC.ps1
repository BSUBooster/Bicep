﻿configuration CreateADPDC
{
   param
   (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature DNS
        {
            Ensure = "Present"
            Name = "DNS"
        }

        Script EnableDNSDiags
        {
      	    SetScript = {
                Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics"
            }
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature DnsTools
        {
            Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
            DependsOn="[WindowsFeature]DNS"
        }

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSTools"
        }

        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "C:\Windows\NTDS"
            LogPath = "C:\Windows\NTDS"
            SysvolPath = "C:\Windows\SYSVOL"
            DependsOn = @("[WindowsFeature]ADDSInstall")
        }

        xPendingReboot RebootAfterPromotion{
            Name = "RebootAfterPromotion"
            DependsOn = "[xADDomain]FirstDS"
        }

        xADOrganizationalUnit BaseOU{
            Ensure = "Present"
            Name = ($DomainName -split '\.')[0]
            Path = ('DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xPendingReboot]RebootAfterPromotion"
        }

        xADOrganizationalUnit ServersOU{
            Ensure = "Present"
            Name = "Servers"
            Path = ('OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]BaseOU"
        }

        xADOrganizationalUnit RDServersOU{
            Ensure = "Present"
            Name = "RD Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit EXCServersOU{
            Ensure = "Present"
            Name = "Exc Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit WEBServersOU{
            Ensure = "Present"
            Name = "Web Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit APPServersOU{
            Ensure = "Present"
            Name = "App Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit PrintServersOU{
            Ensure = "Present"
            Name = "Print Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit ManagementServersOU{
            Ensure = "Present"
            Name = "Management Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit SQLServersOU{
            Ensure = "Present"
            Name = "SQL Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit FileServersOU{
            Ensure = "Present"
            Name = "File Servers"
            Path = ('OU=Servers,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]ServersOU"
        }

        xADOrganizationalUnit WorkstationsOU{
            Ensure = "Present"
            Name = "Workstations"
            Path = ('OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]BaseOU"
        }

        xADOrganizationalUnit WorkstationsWorkstationsOU{
            Ensure = "Present"
            Name = "Workstations"
            Path = ('OU=Workstations,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]WorkstationsOU"
        }

        xADOrganizationalUnit LaptopsWorkstationsOU{
            Ensure = "Present"
            Name = "Laptops"
            Path = ('OU=Workstations,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]WorkstationsOU"
        }

        xADOrganizationalUnit ThinclientsWorkstationsOU{
            Ensure = "Present"
            Name = "Thinclients"
            Path = ('OU=Workstations,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]WorkstationsOU"
        }

        xADOrganizationalUnit GroupsOU{
            Ensure = "Present"
            Name = "Groups"
            Path = ('OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]BaseOU"
        }

        xADOrganizationalUnit UsersOU{
            Ensure = "Present"
            Name = "Users"
            Path = ('OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]BaseOU"
        }
        
        xADOrganizationalUnit ServiceAccountsOU{
            Ensure = "Present"
            Name = "Service Accounts"
            Path = ('OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]BaseOU"
        }
        
        xADOrganizationalUnit SharedMailboxesOU{
            Ensure = "Present"
            Name = "Shared Mailboxes"
            Path = ('OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]BaseOU"
        }
        
        xADOrganizationalUnit ContactsOU{
            Ensure = "Present"
            Name = "Contacts"
            Path = ('OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]BaseOU"
        }

        xADGroup APP_OfficeGroup{
            Ensure = "Present"
            GroupName = "APP_Office"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_RdsGroup{
            Ensure = "Present"
            GroupName = "APP_Rds"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_CitrixGroup{
            Ensure = "Present"
            GroupName = "APP_Citrix"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_OfficeProGroup{
            Ensure = "Present"
            GroupName = "APP_OfficePro"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_SMSpasscodeGroup{
            Ensure = "Present"
            GroupName = "APP_SMSpasscode"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_ResGroup{
            Ensure = "Present"
            GroupName = "APP_Res"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_VisioGroup{
            Ensure = "Present"
            GroupName = "APP_Visio"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_ProjectGroup{
            Ensure = "Present"
            GroupName = "APP_Project"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_SqlGroup{
            Ensure = "Present"
            GroupName = "APP_Sql"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_DuoGroup{
            Ensure = "Present"
            GroupName = "APP_Duo"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_VPNGroup{
            Ensure = "Present"
            GroupName = "APP_VPN"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }

        xADGroup APP_RESVDXGroup{
            Ensure = "Present"
            GroupName = "APP_RESVDX"
            GroupScope = "Global"
            Category = "Security"
            Path = ('OU=Groups,OU={0},DC={0},DC={1}' -f ($DomainName -split '\.')[0], ($DomainName -split '\.')[1])
            DependsOn = "[xADOrganizationalUnit]GroupsOU"
        }
   }
}
